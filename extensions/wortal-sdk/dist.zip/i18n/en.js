"use strict";

module.exports = {
    title: "Wortal SDK",
    description: "Extension for the Wortal SDK to deploy games on the Digital Will HTML5 Game Portal.",
};